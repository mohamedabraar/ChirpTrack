package a.co.varsitycollege.st10091229.poe

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity

class Settings : AppCompatActivity() {

    private lateinit var imageViewProfile: ImageView
    lateinit var editTextName: EditText
    private lateinit var radioGroupUnitSystem: RadioGroup
    lateinit var editTextMaxDistance: EditText
    lateinit var saveSettingsButton: Button
    lateinit var logoffButton: Button

    // Creating SharedPreferences object
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.settings)

        imageViewProfile = findViewById(R.id.imageViewProfile)
        editTextName = findViewById(R.id.editTextName)
        radioGroupUnitSystem = findViewById(R.id.radioGroupUnitSystem)
        editTextMaxDistance = findViewById(R.id.editTextMaxDistance)
        saveSettingsButton = findViewById(R.id.saveSettings)
        logoffButton = findViewById(R.id.LogOff)

        // initialising SharedPreferences object
        sharedPreferences = getSharedPreferences("UserSettings", MODE_PRIVATE)

        // Load saved settings
        loadSettings()

        imageViewProfile.setOnClickListener {
            // Launch gallery to select an image
            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"
            startActivityForResult(intent, REQUEST_IMAGE_PICK)
        }

        saveSettingsButton.setOnClickListener {
            saveSettings()
            finish()
        }

        logoffButton.setOnClickListener {
            // Clear the session information
            clearSession()

            val intent = Intent(this, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
        }
    }

    private fun loadSettings() {
        val name = sharedPreferences.getString("name", "")
        val unitSystem = sharedPreferences.getInt("unitSystem", R.id.radioButtonMetric)
        val maxDistance = sharedPreferences.getString("maxDistance", "")
        val imageUriStr = sharedPreferences.getString("imageUri", null)

        editTextName.setText(name)
        radioGroupUnitSystem.check(unitSystem)
        editTextMaxDistance.setText(maxDistance)

        if (imageUriStr != null) {
            val imageUri = Uri.parse(imageUriStr)
            imageViewProfile.setImageURI(imageUri)
            imageViewProfile.tag = imageUri
        }
    }

    private fun saveSettings() {
        val name = editTextName.text.toString()
        val unitSystem = radioGroupUnitSystem.checkedRadioButtonId
        val maxDistance = editTextMaxDistance.text.toString()

        // Save the settings
        val editor = sharedPreferences.edit()
        editor.putString("name", name)
        editor.putInt("unitSystem", unitSystem)
        editor.putString("maxDistance", maxDistance)

        // Save the image URI if available
        val imageUri = imageViewProfile.tag as? Uri
        if (imageUri != null) {
            editor.putString("imageUri", imageUri.toString())
        }

        editor.apply()
    }

    private fun clearSession() {
        // Clear the session information
        val sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putBoolean("isLoggedIn", false)
        editor.apply()
    }

    companion object {
        private const val REQUEST_IMAGE_PICK = 1
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_IMAGE_PICK && resultCode == RESULT_OK) {
            val imageUri: Uri? = data?.data
            if (imageUri != null) {
                imageViewProfile.setImageURI(imageUri)
                imageViewProfile.tag = imageUri
            }
        }
    }
}