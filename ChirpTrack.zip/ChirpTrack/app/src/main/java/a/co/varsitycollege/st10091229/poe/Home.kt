package a.co.varsitycollege.st10091229.poe

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.crashlytics.buildtools.reloc.com.google.common.collect.Maps

class Home : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.home)

        val settingsButton = findViewById<Button>(R.id.bottom_nav_settings)
        val mapButton = findViewById<Button>(R.id.bottom_nav_map)
        val homeButton = findViewById<Button>(R.id.bottom_nav_home)
        val viewSight = findViewById<Button>(R.id.ViewSightings)
        val addButton = findViewById<Button>(R.id.Add)
        val quizButton = findViewById<Button>(R.id.Questions)

        settingsButton.setOnClickListener {
            val intent = Intent(this, Settings::class.java)
            startActivity(intent)
        }

        mapButton.setOnClickListener {
            val intent = Intent(this, MapActivity::class.java)
            startActivity(intent)
        }

        homeButton.setOnClickListener {
            val intent = Intent(this, Home::class.java)
            startActivity(intent)
        }

        viewSight.setOnClickListener {
            val intent = Intent(this, ViewSight::class.java)
            startActivity(intent)
        }

        addButton.setOnClickListener {
            val intent = Intent(this, AddSight::class.java)
            startActivity(intent)
        }

        quizButton.setOnClickListener {
            val intent = Intent(this, QuizActivity::class.java)
            startActivity(intent)
        }
    }

    private fun clearSession() {
        // Clear the session information
        val sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putBoolean("isLoggedIn", false)
        editor.apply()
    }
}