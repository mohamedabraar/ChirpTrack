package a.co.varsitycollege.st10091229.poe

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import android.widget.TextView
import android.content.SharedPreferences


class MainActivity : AppCompatActivity() {

    private lateinit var tvRedirectSignUp: TextView
    lateinit var etEmail: EditText
    private lateinit var etPass: EditText
    lateinit var btnLogin: Button
    lateinit var checkBox: CheckBox

    // Creating firebaseAuth object
    lateinit var auth: FirebaseAuth

    // Creating SharedPreferences object
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // View Binding
        tvRedirectSignUp = findViewById(R.id.register)
        btnLogin = findViewById(R.id.loginButton)
        etEmail = findViewById(R.id.EmailEditText)
        etPass = findViewById(R.id.passwordEditText)
        checkBox = findViewById(R.id.checkBox)

        // initialising Firebase auth object
        auth = FirebaseAuth.getInstance()

        // initialising SharedPreferences object
        sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE)

        // Check if the user is already logged in
        if (isLoggedIn()) {
            redirectToHome()
        }

        btnLogin.setOnClickListener {
            login()
        }

        tvRedirectSignUp.setOnClickListener {
            val intent = Intent(this, RegistrationActivity::class.java)
            startActivity(intent)
            // using finish() to end the activity
            finish()
        }
    }

    private fun login() {
        val email = etEmail.text.toString()
        val pass = etPass.text.toString()

        // calling signInWithEmailAndPassword(email, pass)
        // function using Firebase auth object
        // On successful response Display a Toast
        auth.signInWithEmailAndPassword(email, pass).addOnCompleteListener(this) {
            if (it.isSuccessful) {
                Toast.makeText(this, "Successfully LoggedIn", Toast.LENGTH_SHORT).show()

                // Check if the user wants to stay signed in
                val currentUser = auth.currentUser
                val stayLoggedIn = checkBox.isChecked

                if (currentUser != null) {
                    if (stayLoggedIn) {
                        // Save the session information and redirect to home activity
                        saveSession()
                    }
                    redirectToHome()
                }
            } else {
                Toast.makeText(this, "Log In failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun saveSession() {
        // Save the session information
        val editor = sharedPreferences.edit()
        editor.putBoolean("isLoggedIn", true)
        editor.apply()
    }

    private fun isLoggedIn(): Boolean {
        return sharedPreferences.getBoolean("isLoggedIn", false)
    }

    private fun redirectToHome() {
        val intent = Intent(this, Home::class.java)
        startActivity(intent)
        // using finish() to end the activity
        finish()
    }
}