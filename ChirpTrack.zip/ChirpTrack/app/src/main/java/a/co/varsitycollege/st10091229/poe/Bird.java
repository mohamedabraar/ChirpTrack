package a.co.varsitycollege.st10091229.poe;
public class Bird {
    private String birdName;
    private String birdDescription;

    public Bird(String birdName, String birdDescription, String imageUrl) {
        // Default constructor required for DataSnapshot.getValue(Bird.class)
    }

    public Bird(String birdName, String birdDescription) {
        this.birdName = birdName;
        this.birdDescription = birdDescription;
    }

    public String getBirdName() {
        return birdName;
    }

    public void setBirdName(String birdName) {
        this.birdName = birdName;
    }

    public String getBirdDescription() {
        return birdDescription;
    }

    public void setBirdDescription(String birdDescription) {
        this.birdDescription = birdDescription;
    }
}
