package a.co.varsitycollege.st10091229.poe

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.OnProgressListener
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.UploadTask
import java.io.IOException

class AddSight : AppCompatActivity() {
    private var birdNameEditText: EditText? = null
    private var birdDescriptionEditText: EditText? = null
    private var selectedImageView: ImageView? = null
    private var choosePictureButton: Button? = null
    private var submitButton: Button? = null
    private var databaseReference: DatabaseReference? = null
    private var storageReference: StorageReference? = null
    private var imageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.add_sighting)

        birdNameEditText = findViewById(R.id.birdNameEditText)
        birdDescriptionEditText = findViewById(R.id.birdDescriptionEditText)
        selectedImageView = findViewById(R.id.selectedImageView)
        choosePictureButton = findViewById(R.id.choosePictureButton)
        submitButton = findViewById(R.id.submit)

        val firebaseDatabase = FirebaseDatabase.getInstance()
        databaseReference = firebaseDatabase.getReference("Bird")

        val firebaseStorage = FirebaseStorage.getInstance()
        storageReference = firebaseStorage.reference.child("uploads")

        choosePictureButton?.setOnClickListener { choosePicture() }
        submitButton?.setOnClickListener { submit() }
    }

    private fun choosePicture() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "image/*"
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.data != null) {
            imageUri = data.data
            try {
                val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, imageUri)
                selectedImageView?.setImageBitmap(bitmap)
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }

    private fun submit() {
        val birdName = birdNameEditText?.text.toString().trim()
        val birdDescription = birdDescriptionEditText?.text.toString().trim()

        if (birdName.isNotEmpty() && birdDescription.isNotEmpty() && imageUri != null) {
            val fileReference =
                storageReference?.child("${System.currentTimeMillis()}.${getFileExtension(imageUri!!)}")
            fileReference?.putFile(imageUri!!)
                ?.addOnSuccessListener {
                    fileReference.downloadUrl.addOnSuccessListener { uri ->
                        val imageUrl = uri.toString()

                        val key = databaseReference?.push()?.key
                        val birdSighting = Bird(birdName, birdDescription, imageUrl)

                        if (key != null) {
                            databaseReference?.child(key)?.setValue(birdSighting)
                                ?.addOnSuccessListener {
                                    birdNameEditText?.setText("")
                                    birdDescriptionEditText?.setText("")
                                    selectedImageView?.setImageResource(android.R.drawable.ic_menu_gallery)
                                    imageUri = null

                                    showToast("Sighting submitted successfully.")
                                }
                                ?.addOnFailureListener {
                                    showToast("Failed to submit sighting.")
                                }
                        }
                    }
                }
                ?.addOnFailureListener {
                    showToast("Failed to upload image.")
                }
                ?.addOnProgressListener { taskSnapshot ->
                    // Implement progress listener if needed
                }

        } else {
            showToast("Please provide a bird name, description, and select an image.")
        }
    }

    private fun getFileExtension(uri: Uri): String? {
        val contentResolver = contentResolver
        val mimeTypeMap = MimeTypeMap.getSingleton()
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri))
    }

    private fun showToast(message: String) {
        Toast.makeText(this@AddSight, message, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val PICK_IMAGE_REQUEST = 1
    }


}