package a.co.varsitycollege.st10091229.poe;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;

public class ViewSight extends AppCompatActivity {
    private ListView sightingsListView;
    private List<String> sightingsList;
    private ArrayAdapter<String> sightingsAdapter;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_sightings);

        sightingsListView = findViewById(R.id.sightingsListView);
        sightingsList = new ArrayList<>();
        sightingsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, sightingsList);
        sightingsListView.setAdapter(sightingsAdapter);

        // Initialize the Firebase Realtime Database
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Bird");

        // Read bird sightings from Firebase and populate the list
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                sightingsList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Bird birdSighting = snapshot.getValue(Bird.class);
                    if (birdSighting != null) {
                        String sightingInfo = "Bird Name: " + birdSighting.getBirdName() + "\nDescription: " + birdSighting.getBirdDescription();
                        sightingsList.add(sightingInfo);
                    }
                }
                sightingsAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle any errors
            }
        });
    }
}

