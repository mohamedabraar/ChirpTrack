package a.co.varsitycollege.st10091229.poe

data class BirdingHotspot(
    val id: String, // Unique ID of the hotspot
    val name: String, // Name of the hotspot
    val latitude: Double, // Latitude of the hotspot's location
    val longitude: Double, // Longitude of the hotspot's location
    val description: String, // Description of the hotspot
    val rating: Double // Rating or popularity of the hotspot
)



