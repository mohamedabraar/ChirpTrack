package a.co.varsitycollege.st10091229.poe

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class QuizActivity : AppCompatActivity() {

    private lateinit var questionTextView: TextView
    private lateinit var optionsRadioGroup: RadioGroup
    private lateinit var optionARadioButton: RadioButton
    private lateinit var optionBRadioButton: RadioButton
    private lateinit var optionCRadioButton: RadioButton
    private lateinit var optionDRadioButton: RadioButton
    private lateinit var submitButton: Button

    private val questions = listOf(
        Question("What is the largest bird in the world?", "Ostrich", "Emu", "Albatross", "Condor", "A"),
        Question("Which bird is known for its ability to mimic human speech?", "Penguin", "Parrot", "Cuckoo", "Woodpecker", "B"),
        Question("Which bird is known for its long migration journeys, often spanning thousands of miles?", "Swan", "Penguin", "Albatross", "Eagle", "C"),
        Question("What is the smallest bird in the world?", "Hummingbird", "Sparrow", "Finch", "Robin", "A"),
        Question("Which bird is the national symbol of the United States?", "Bald Eagle", "Peregrine Falcon", "American Robin", "Great Horned Owl", "A"),
        Question("Which bird is often associated with delivering babies in folklore?", "Stork", "Crane", "Pelican", "Seagull", "A"),
        Question("What is the largest flying bird in the world?", "Bald Eagle", "Andean Condor", "Wandering Albatross", "Golden Eagle", "C"),
        Question("Which bird is known for its distinctive laughing call?", "Kookaburra", "Toucan", "Loon", "Magpie", "A"),
        Question("Which bird is famous for its ability to imitate human speech and sounds?", "Cockatoo", "Starling", "Myna Bird", "Lyrebird", "D"),
        Question("In which continent can you find penguins in the wild?", "Asia", "Africa", "Antarctica", "South America", "C")
        )

    private var currentQuestionIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.quiz)

        // Initialize UI elements
        questionTextView = findViewById(R.id.questionTextView)
        optionsRadioGroup = findViewById(R.id.optionsRadioGroup)
        optionARadioButton = findViewById(R.id.optionARadioButton)
        optionBRadioButton = findViewById(R.id.optionBRadioButton)
        optionCRadioButton = findViewById(R.id.optionCRadioButton)
        optionDRadioButton = findViewById(R.id.optionDRadioButton)
        submitButton = findViewById(R.id.submitButton)

        // Load the first question
        loadQuestion()

        // Set click listener for the Submit button
        submitButton.setOnClickListener {
            checkAnswer()
        }
    }

    private fun loadQuestion() {
        // Check if there are more questions
        if (currentQuestionIndex < questions.size) {
            val currentQuestion = questions[currentQuestionIndex]

            // Set question and options
            questionTextView.text = currentQuestion.question
            optionARadioButton.text = currentQuestion.optionA
            optionBRadioButton.text = currentQuestion.optionB
            optionCRadioButton.text = currentQuestion.optionC
            optionDRadioButton.text = currentQuestion.optionD

            // Clear radio button selection
            optionsRadioGroup.clearCheck()
        } else {
            // All questions answered
            Toast.makeText(this, "Quiz completed!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun checkAnswer() {
        val selectedOption: String? = when (optionsRadioGroup.checkedRadioButtonId) {
            R.id.optionARadioButton -> "A"
            R.id.optionBRadioButton -> "B"
            R.id.optionCRadioButton -> "C"
            R.id.optionDRadioButton -> "D"
            else -> null
        }

        if (selectedOption == questions[currentQuestionIndex].correctAnswer) {
            Toast.makeText(this, "Correct!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Incorrect. The correct answer is ${questions[currentQuestionIndex].correctAnswer}", Toast.LENGTH_SHORT).show()
        }

        // Move to the next question
        currentQuestionIndex++
        loadQuestion()
    }

    data class Question(
        val question: String,
        val optionA: String,
        val optionB: String,
        val optionC: String,
        val optionD: String,
        val correctAnswer: String
    )
}
