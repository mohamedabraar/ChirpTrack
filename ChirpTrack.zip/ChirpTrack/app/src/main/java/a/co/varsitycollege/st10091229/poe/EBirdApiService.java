package a.co.varsitycollege.st10091229.poe;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface EBirdApiService {
    @GET("data/obs/geo/recent")
    Call<List<BirdingHotspot>> getBirdingHotspots(
            @Query("lat") double lat,
            @Query("lng") double lng,
            @Query("dist") int dist,
            @Query("maxResults") int maxResults,
            @Query("key") String key
    );

    @GET("data/obs/geo/recent")
    @Nullable
    Call<List<BirdingHotspot>> getBirdingHotspots(
            @Query("key") String eBirdApiKey,
            @Query("lat") double latitude,
            @Query("lng") double longitude
    );
}

